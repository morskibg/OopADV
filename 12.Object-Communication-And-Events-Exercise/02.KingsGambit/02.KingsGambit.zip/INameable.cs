﻿public interface INameable
{
    string Name { get; }
}